import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Wagon from './components/wagon/wagon';
import '../src/App.css'

const App = () => {
  const API_URL = "https://localhost:7111";
  const [wagons, setWagons] = useState([]);
  const [error, setError] = useState('');

  const fetchWagons = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/wagon/getwagons`);
      setWagons(response.data);
      setError('');
    } catch (err) {
      if (err.response) {
        setError('Failed to fetch wagons');
      } else if (err.request) {
        setError('API is not running. Please check your connection.');
      } else {
        setError('An unexpected error occurred');
      }
    }
  };

  const addWagon = async (position) => {
    try {
      await axios.post(`${API_URL}/api/wagon/insert`, position, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      fetchWagons();
      setError('');
    } catch (err) {
      if (err.response) {
        setError('Failed to add wagon');
      } else if (err.request) {
        setError('API is not running. Please check your connection.');
      } else {
        setError('An unexpected error occurred');
      }
    }
  };

  const removeWagon = async (position) => {
    try {
      await axios.post(`${API_URL}/api/wagon/remove`, position, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      fetchWagons();
      setError('');
    } catch (err) {
      if (err.response) {
        setError(err.response?.data || 'Failed to remove wagon');
      } else if (err.request) {
        setError('API is not running. Please check your connection.');
      } else {
        setError('An unexpected error occurred');
      }
    }
  };

  useEffect(() => {
    fetchWagons();
  }, []);

  return (
    <div className='container-fluid wagon-container'>
      <h1 className='text-center'>Train Wagons</h1>
      <div className='btn-container'>
        <button type="button" className="btn btn-primary m-3" onClick={() => addWagon('d')}>Add Wagon to Right</button>
        <button className="btn btn-secondary m-3" onClick={() => addWagon('i')}>Add Wagon to Left</button>
        <button className="btn btn-warning m-3" onClick={() => removeWagon('d')}>Remove Wagon from Right</button>
        <button className="btn btn-danger m-3" onClick={() => removeWagon('i')}>Remove Wagon from Left</button>
      </div>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div className="text-center wagons">
        {wagons.map((wagon, index) => (
          <Wagon key={index} position={wagon.position} />
        ))}
      </div>
    </div>
  );
};

export default App;
