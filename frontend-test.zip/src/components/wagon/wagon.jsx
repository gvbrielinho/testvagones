import React from 'react';
import '../wagon/wagon.css';

const Wagon = ({ position }) => {
    return (
        <div className={`wagon ${position === 'd' ? 'right' : 'left'}`}>
            {position}
        </div>
    );
};

export default Wagon;
