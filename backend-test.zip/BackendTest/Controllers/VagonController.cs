﻿using BackendTest.Interfaces;
using BackendTest.Models;
using BackendTest.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace BackendTest.Controllers
{
    [Route("api/wagon")]
    [ApiController]
    public class WagonController : ControllerBase
    {
        private readonly IWagonService _wagonService;
        private static readonly List<Wagon> wagons = new();

        public WagonController(IWagonService wagonService)
        {
            _wagonService = wagonService;
        }

        [HttpPost("insert")]
        public ActionResult AddWagon([FromBody] string position)
        {
            var newWagon = new Wagon { Position = position };
            _wagonService.AddWagon(wagons, newWagon, position);
            return Ok(newWagon);
        }

        [HttpPost("remove")]
        public ActionResult RemoveWagon([FromBody] string position)
        {
            try
            {
                _wagonService.RemoveWagon(wagons, position);
                return Ok();
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("getwagons")]
        public ActionResult<List<Wagon>> GetWagons()
        {
            return Ok(wagons);
        }
    }
}
