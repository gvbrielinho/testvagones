﻿namespace BackendTest.DTOs
{
    public class WagonDTO
    {
        public string Position { get; set; } = string.Empty;
    }
}
