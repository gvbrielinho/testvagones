﻿using System.Xml.Linq;

namespace BackendTest.Models
{
    //    ¡Hola! Gracias por tomarte este tiempo para resolver este ejercicio.Se trata de una
    //actividad en donde se debe aplicar lógica de programación(¡y por supuesto
    //programación!). No tiene “trampas” ni nada que haya que deducir fuera del
    //enunciado.
    //ENUNCIADO
    //Estoy parado frente a unas vías de tren, y tengo a mi disposición infinidad de
    //vagones de carga.Cada vagón lleva un número y la idea es ir armando un tren con
    //estos vagones (¡no pienses en tener que mover físicamente vagones o trenes!). 
    //Para ello, el usuario me va a pedir por pantalla, de forma aleatoria, que: 
    //• Enganche un vagón con número “X” a la izquierda o a la derecha 
    //• Desenganche un vagón de la izquierda o de la derecha
    //El objetivo es recibir las instrucciones de enganche y desenganche de vagones, y
    //visualizar mi tren en pantalla a medida que se va armando.Cada vez que el usuario
    //engancha o desengancha un vagón, el tren se debe actualizar en pantalla.
    //No es crucial preocuparse por la representación visual del sistema.Puedes
    //abordarlo desarrollando una aplicación web utilizando.NET para el servidor y React
    //para el cliente.
    public class Wagon
    {
        public string Position { get; set; } = string.Empty;
    }

}
