﻿using System.Collections.Generic;
using BackendTest.Models;

namespace BackendTest.Interfaces
{
    public interface IWagonService
    {
        void AddWagon(List<Wagon> wagons, Wagon wagon, string position);
        void RemoveWagon(List<Wagon> wagons, string position);
    }
}
