﻿using BackendTest.Interfaces;
using BackendTest.Models;
using System;
using System.Collections.Generic;

namespace BackendTest.Services
{
    public class WagonService : IWagonService
    {
        public void AddWagon(List<Wagon> wagons, Wagon wagon, string position)
        {
            if (position.ToLower() == "d")
                wagons.Add(wagon);
            else if (position.ToLower() == "i")
                wagons.Insert(0, wagon);
        }

        public void RemoveWagon(List<Wagon> wagons, string position)
        {
            if (wagons.Count == 0)
                throw new InvalidOperationException("No more wagons attached!");

            if (position.ToLower() == "d")
                wagons.RemoveAt(wagons.Count - 1);
            else if (position.ToLower() == "i")
                wagons.RemoveAt(0);
        }
    }
}
